// Optional JS for interactivity later
console.log("Blush Bakes loaded!");